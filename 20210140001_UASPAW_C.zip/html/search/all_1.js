var searchData=
[
  ['data_0',['data',['../classtesting__uas__kasir_1_1_program.html#a846574f22c59d134b7514a83641e7803',1,'testing_uas_kasir::Program']]]
];
