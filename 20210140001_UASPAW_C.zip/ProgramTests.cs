﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using testing_uas_kasir;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing_uas_kasir.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void dataTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void dataTest1()
        {

        }

        [TestMethod()]
        public void dataTest2()
        {

        }
    }
}