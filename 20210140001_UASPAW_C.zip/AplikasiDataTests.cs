﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp30;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp30.Tests
{
    [TestClass()]
    public class AplikasiDataTests
    {
        [TestMethod()]
        public void InputDataTest(Assert assert)
        {
            Assert.Fail();
        }
    }
}