﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace testing_uas_kasir
{
    public class Program
    {
        public int pilih, banyak, banyak1, banyak2, banyak3, banyak4;
        public int hasil, hasil1, hasil2, hasil3, hasil4;

        public void data()
        {
            Console.WriteLine("Menu");
            Console.WriteLine("1. Bubur Ayam        Rp. 10000");
            Console.WriteLine("2. Nasi Padang       Rp. 10000");
            Console.WriteLine("3. Gudeg             Rp. 10000");
            Console.WriteLine("4. Es Jeruk          Rp. 4000");
            Console.WriteLine("5. Es Teh            Rp. 3000");
            Console.WriteLine("6. Exit");
            Console.WriteLine();

            string nama, kasir;
            Console.Write("Nama Pelanggan        : ");
            nama = Convert.ToString(Console.ReadLine());
            Console.Write("Nama Kasir            : ");
            kasir = Convert.ToString(Console.ReadLine());
            Console.WriteLine(DateTime.Now);
            Console.ReadLine();
            Console.WriteLine("Pilih (1/2/3/4/5/6");
            pilih = Convert.ToInt32(Console.ReadLine());
            switch (pilih)
            {
                case 1:
                    Console.Write("Berapa banyak yang kamu mau beli : ");
                    banyak = Convert.ToInt32(Console.ReadLine());
                    hasil = banyak * 10000;
                    break;
                case 2:
                    Console.Write("Berapa banyak yang kamu mau beli : ");
                    banyak1 = Convert.ToInt32(Console.ReadLine());
                    hasil1 = banyak1 * 10000;
                    break;
                case 3:
                    Console.Write("Berapa banyak yang kamu mau beli : ");
                    banyak2 = Convert.ToInt32(Console.ReadLine());
                    hasil2 = banyak2 * 10000;
                    break;
                case 4:
                    Console.Write("Berapa banyak yang kamu mau beli : ");
                    banyak3 = Convert.ToInt32(Console.ReadLine());
                    hasil3 = banyak3 * 4000;
                    break;
                case 5:
                    Console.Write("Berapa banyak yang kamu mau beli : ");
                    banyak4 = Convert.ToInt32(Console.ReadLine());
                    hasil4 = banyak4 * 3000;
                    break;
                case 6:
                    Console.WriteLine();
                    break;
                default:
                    Console.WriteLine("Pilihan anda salah!");
                    Console.Read();
                    break;

            }
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            string ulang;
            int total = 0;
            int bayar, kembali;

            Console.WriteLine("Selamat datang di Warung Makan!");
            Console.WriteLine("Silahkan Pilih menu dibawah ini!");
            Console.WriteLine("================================");
            do
            {
                do
                {
                    p.data();
                } while (p.pilih != 6);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("                 NOTA                ");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine($"{p.banyak} Bubur Ayam \t = Rp. {p.hasil}");
                Console.WriteLine($"{p.banyak1} Nasi Padang \t = Rp. {p.hasil1}");
                Console.WriteLine($"{p.banyak2} Gudeg \t = Rp. {p.hasil2}");
                Console.WriteLine($"{p.banyak3} Es Jeruk \t = Rp. {p.hasil3}");
                Console.WriteLine($"{p.banyak4} Es Teh \t = Rp. {p.hasil4}");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine($"Total =  + {p.hasil + p.hasil1 + p.hasil2 + p.hasil3 + p.hasil4}");
                Console.WriteLine("=====================================");
                Console.WriteLine("Total            " + (p.hasil + p.hasil1 + p.hasil2 + p.hasil3 + p.hasil4));

                do
                {
                    Console.Write("\n \n Uang Bayar : ");
                    bayar = int.Parse(Console.ReadLine());
                    kembali = bayar - (p.hasil + p.hasil1 + p.hasil2 + p.hasil3 + p.hasil4);

                    if (bayar < (p.hasil + p.hasil1 + p.hasil2 + p.hasil3 + p.hasil4))
                    {
                        Console.WriteLine("Maaf Uang Anda Kurang");
                        Console.WriteLine("-------------------------------");
                    }
                    else
                    {
                        Console.WriteLine("Uang Kembalian Anda Rp. " + kembali + ",00");
                    }

                    Console.WriteLine("Apakah Anda ingin kembali berbelanja?");
                    Console.Write("Tekan 'y' untuk melanjutkan atau tekan 'enter' untuk keluar.");
                    Console.WriteLine();
                    ulang = Console.ReadLine();
                }

                while (ulang == "yes");
            } while (bayar < (p.hasil + p.hasil1 + p.hasil2 + p.hasil3 + p.hasil4));

        }
    }
}